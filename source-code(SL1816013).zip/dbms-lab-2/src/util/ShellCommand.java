package util;


import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.IOUtils;

public class ShellCommand
{
    /**
     * @param command
     * @return
     * @throws ExecutionFailedException
     * @throws InterruptedException
     * @throws IOException
     */
    public static List< String > execute( final String command )
            throws ExecutionFailedException, InterruptedException, IOException
    {
        try {
            return execute( command, 0, null, false, false );
        } catch ( ExecutionTimeoutException e ) {
            /* Impossible case! */
            return null;
        }
    }


    /**
     * @param command
     * @param timeout
     * @param timeUnit
     * @return
     * @throws ExecutionFailedException
     * @throws ExecutionTimeoutException
     * @throws InterruptedException
     * @throws IOException
     */
    public static List< String > execute( final String command, final long timeout, final TimeUnit timeUnit )
            throws ExecutionFailedException, ExecutionTimeoutException, InterruptedException, IOException
    {
        return execute( command, timeout, timeUnit, true, false );
    }


    /**
     * @param command
     * @return
     * @throws ExecutionFailedException
     * @throws InterruptedException
     * @throws IOException
     */
    public static List< String > executeIgnoreFail( final String command )
            throws ExecutionFailedException, InterruptedException, IOException
    {
        try {
            return execute( command, 0, null, false, true );
        } catch ( ExecutionTimeoutException e ) {
            /* Impossible case! */
            return null;
        }
    }


    /**
     * @param command
     * @param timeout
     * @param timeUnit
     * @return
     * @throws ExecutionFailedException
     * @throws ExecutionTimeoutException
     * @throws InterruptedException
     * @throws IOException
     */
    public static List< String > executeIgnoreFail( final String command, final long timeout, final TimeUnit timeUnit )
            throws ExecutionFailedException, ExecutionTimeoutException, InterruptedException, IOException
    {
        return execute( command, timeout, timeUnit, true, true );
    }


    /**
     * @param command
     * @param timeout
     * @param timeUnit
     * @param destroyOnTimeout
     * @return
     * @throws ExecutionFailedException
     * @throws ExecutionTimeoutException
     * @throws InterruptedException
     * @throws IOException
     */
    public static List< String > execute( final String command,
            final long timeout,
            final TimeUnit timeUnit,
            boolean destroyOnTimeout,
            boolean ignoreFail )
            throws ExecutionFailedException, ExecutionTimeoutException, InterruptedException, IOException
    {

        ProcessBuilder builder = new ProcessBuilder().redirectErrorStream( true );
        if ( CheckOperatingSystem.isWindows() ) {
            builder.command( "cmd.exe", "/c", command );
        } else {
            builder.command( "bash", "-c", command );
        }
        Process process = builder.start();

        List< String > processOutput = IOUtils.readLines( process.getInputStream(), StandardCharsets.UTF_8 );

        if ( !ignoreFail ) {

            if ( timeUnit != null ) {
                if ( process.waitFor( timeout, timeUnit ) ) {
                    if ( process.exitValue() == 0 ) {
                        return processOutput;
                    } else {
                        throw new ExecutionFailedException( "Execution failed: " + command,
                                process.exitValue(),
                                processOutput );
                    }
                } else {
                    if ( destroyOnTimeout ) {
                        process.destroy();
                    }
                    throw new ExecutionTimeoutException( "Execution timed out: " + command );
                }
            } else {
                if ( process.waitFor() == 0 ) {
                    return processOutput;
                } else {
                    throw new ExecutionFailedException( "Execution failed: " + command,
                            process.exitValue(),
                            processOutput );
                }
            }

        } else { // only used when testing

            if ( timeUnit != null ) {
                if ( process.waitFor( timeout, timeUnit ) ) {
                    return processOutput;
                } else {
                    if ( destroyOnTimeout ) {
                        process.destroy();
                    }
                    throw new ExecutionTimeoutException( "Execution timed out: " + command );
                }
            } else {
                process.waitFor();
                return processOutput;
            }
        }

    }

    public static class ExecutionFailedException extends Exception
    {
        private static final long serialVersionUID = 1951044996696304510L;

        private final int exitCode;
        private final List< String > errorOutput;


        public ExecutionFailedException( final String message, final int exitCode, final List< String > errorOutput )
        {
            super( message );
            this.exitCode = exitCode;
            this.errorOutput = errorOutput;
        }


        public int getExitCode()
        {
            return this.exitCode;
        }


        public List< String > getErrorOutput()
        {
            return this.errorOutput;
        }
    }

    public static class ExecutionTimeoutException extends Exception
    {
        private static final long serialVersionUID = 4428595769718054862L;


        public ExecutionTimeoutException( final String message )
        {
            super( message );
        }
    }

    public static class CheckOperatingSystem
    {
        private static String OS = null;


        public static String getOsName()
        {
            if ( OS == null ) {
                OS = System.getProperty( "os.name" ).toLowerCase();
            }

            return OS;
        }


        public static boolean isWindows()
        {
            return ( getOsName().indexOf( "win" ) >= 0 );
        }


        public static boolean isMac()
        {
            return ( getOsName().indexOf( "mac" ) >= 0 );
        }


        public static boolean isUnix()
        {
            return ( getOsName().indexOf( "nux" ) >= 0 );
        }
    }

}
