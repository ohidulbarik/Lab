
import java.util.*;

import util.ShellCommand;
import util.ShellCommand.ExecutionFailedException;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.*;

public class Main
{

    private static final String DATABASE_URL = "localhost:3306";
    private static final String DATABASE_NAME = "dbms_lab";
    private static final String DATABASE_USER = "root";
    private static final String DATABASE_PASSWORD = "root";

    private static final String INITIAL_DATABASE_SETUP = "data/table-setup.sql";

    private static final String[] TEN_REQUIRED_INPUTS = { "data/input1.csv",
            "data/input2.csv",
            "data/input3.csv",
            "data/input4.csv",
            "data/input5.csv",
            "data/input6.csv",
            "data/input7.csv",
            "data/input8.csv",
            "data/input9.csv",
            "data/input10.csv" };


    public static void main( String[] args )
    {
        Connection conn = null;

        System.out.println( "Connecting to the database..." );
        try {
            // Create MySql Connection
            Class.forName( "com.mysql.cj.jdbc.Driver" );
            conn = DriverManager.getConnection( "jdbc:mysql://" + DATABASE_URL + "/" + DATABASE_NAME,
                    DATABASE_USER,
                    DATABASE_PASSWORD );
        } catch ( SQLException se ) {
            se.printStackTrace();
            System.out.println( "Can't connect to the database" );
        } catch ( Exception e ) {
            e.printStackTrace();
            System.out.println( "Can't connect to the database" );
        }
        System.out.println( "Succesfully connect to the database" );

        // Some intro banner
        System.out.println( "\n///////////////////////////////////////////////////////////////////////////////"
                + "\n////////////////// Database Management Information System /////////////////////"
                + "\n///////////////////// By: Yudistira Ashadi - SL1816002 ////////////////////////"
                + "\n///////////////////////////////////////////////////////////////////////////////" );
        mainMenu( conn );
        System.out.println( "Thank you and Have a Good Day ~~~" );
    }


    static public void mainMenu( Connection conn )
    {

        // Main menu list
        boolean exit = false;
        int choose = 0;

        while ( !exit ) {
            System.out.println( "\n\n--------------------------------------------------------------" );
            System.out.println( "\n                         Main Menu                            " );
            System.out.println( "\n--------------------------------------------------------------" );

            System.out.println( "\n1.   Display All Employees\n"
                    + "2.   Add New Employee (write manually)\n"
                    + "3.   Add Employee data with a csv file\n"
                    + "4.   Delete an Employee\n"
                    + "5.   Update an Employee\n"
                    + "6.   Search Employee(s)\n"
                    + "7.   Set-up Initial Table (will reset table to the initial state)\n"
                    + "8.   Exit\n" );

            choose = 0;
            Scanner user_input = null;
            try {
                // A loop to check if the input not in 1 to 6 or in illegal format
                user_input = new Scanner( System.in );
                do {
                    System.out.println( "Enter the desired functionality (integer number) ..." );

                    while ( !user_input.hasNextInt() ) {
                        System.out.println( "Input should be an integer!" );
                        user_input.next();
                    }

                    choose = user_input.nextInt();
                } while ( ( choose < 1 ) || ( choose > 8 ) );
            } catch ( Exception e ) {
                e.printStackTrace();
            } finally {
                user_input.nextLine();
            }

            switch ( choose ) {
                case 1:
                    viewTable( conn );
                    break;
                case 2:
                    insertNewEmployeeManually( conn );
                    break;
                case 3:
                    insertNewEmployeeFromCsv( conn );
                    break;
                case 4:
                    deleteAnEmployee( conn );
                    break;
                case 5:
                    updateAnEmployee( conn );
                    break;
                case 6:
                    searchEmployee( conn );
                    break;
                case 7:
                    setupInitialTable();
                    break;
                default:
                    exit = true;
            }
        }
    }


    static public void viewTable( Connection conn )
    {
        String query = "SELECT * FROM employees";
        int totalEmployees = 0;

        try ( Statement stmt = conn.createStatement() ) {

            ResultSet rs = stmt.executeQuery( query );

            System.out.println( "\n--------------------------------------------------------------" );
            System.out.println( "\n                   Display All Employees                      " );
            System.out.println( "\n--------------------------------------------------------------" );

            while ( rs.next() ) {
                int id = rs.getInt( "id" );
                String lastName = rs.getString( "last_name" );
                String firstName = rs.getString( "first_name" );
                String email = rs.getString( "email" );
                String department = rs.getString( "department" );
                double salary = rs.getDouble( "salary" );

                System.out.println( "ID: "
                        + id
                        + "\nName: "
                        + lastName
                        + ", "
                        + firstName
                        + "\nEmail: "
                        + email
                        + "\nDepartment: "
                        + department
                        + "\nSalary: "
                        + salary );
                System.out.println( "---------------------" );
                totalEmployees++;

            }

            System.out.println( "TOTAL: " + totalEmployees + " employees" );
        } catch ( SQLException se ) {
            se.printStackTrace();
        } catch ( Exception e ) {
            e.printStackTrace();
        }

        Scanner user_input = null;
        try {
            user_input = new Scanner( System.in );
            System.out.println( "\nGo to Main Menu?(Press Enter): " );

            while ( !user_input.hasNextLine() ) {
                System.out.println( "Input something ..." );
                user_input.next();
            }

        } catch ( Exception e ) {
            e.printStackTrace();
        } finally {
            user_input.nextLine();
        }
    }


    static public void insertNewEmployeeManually( Connection conn )
    {
        System.out.println( "\n\n--------------------------------------------------------------" );
        System.out.println( "\n                     Add New Employee                         " );
        System.out.println( "\n--------------------------------------------------------------" );

        Scanner user_input = null;

        String lastName = "";
        String firstName = "";
        String email = "";
        String department = "";
        double salary = 0.0;

        // User input values
        try {

            user_input = new Scanner( System.in );

            // Insert last name
            System.out.print( "Input Last Name: " );
            while ( !user_input.hasNextLine() ) {
                System.out.println( "Input should be a string!" );
                user_input.next();
            }
            lastName = user_input.nextLine();

            // Insert first name
            System.out.print( "Input First Name: " );
            while ( !user_input.hasNextLine() ) {
                System.out.println( "Input should be a string!" );
                user_input.next();
            }
            firstName = user_input.nextLine();

            // Insert email
            System.out.print( "Input Email: " );
            while ( !user_input.hasNextLine() ) {
                System.out.println( "Input should be a string!" );
                user_input.next();
            }
            email = user_input.nextLine();

            // Insert employee's department
            System.out.print( "Input Department: " );
            while ( !user_input.hasNextLine() ) {
                System.out.println( "Input should be a string!" );
                user_input.next();
            }
            department = user_input.nextLine();

            // Insert salary
            System.out.print( "Input Salary: " );
            while ( !user_input.hasNextDouble() ) {
                System.out.println( "Input should be in double type!" );
                user_input.next();
            }
            salary = user_input.nextDouble();
        } catch ( Exception e ) {
            e.printStackTrace();
        } finally {
            user_input.nextLine();
        }

        System.out.println( "\nInserting new record..." );
        String query = ( "INSERT INTO employees "
                + "VALUES("
                + "NULL"
                + ", "
                + "\""
                + lastName
                + "\", "
                + "\""
                + firstName
                + "\", "
                + "\""
                + email
                + "\", "
                + "\""
                + department
                + "\", "
                + salary
                + ")" );

        // Run executeUpdate to communicate with database
        try ( Statement stmt = conn.createStatement() ) {
            stmt.executeUpdate( query );
        } catch ( SQLException ex ) {
            ex.printStackTrace();
        }

        System.out.println( "Record inserted..." );
        // A pause system so user can see the result
        try {
            user_input = new Scanner( System.in );
            System.out.println( "\nGo to Main Menu?(Press Enter): " );

            while ( !user_input.hasNextLine() ) {
                System.out.println( "Input something ..." );
                user_input.next();
            }

        } catch ( Exception e ) {
            e.printStackTrace();
        } finally {
            user_input.nextLine();
        }
    }


    static public void insertNewEmployeeFromCsv( Connection conn )
    {
        System.out.println( "\n\n--------------------------------------------------------------" );
        System.out.println( "\n                     Add New Employee                         " );
        System.out.println( "\n--------------------------------------------------------------" );

        System.out.println( "1.   Insert a file\n" + "2.   Insert input1.csv to input10.csv (10 input files)\n" );

        Scanner user_input = null;
        int choose = 0;

        try {
            // A loop to check if the input not in 1 to 6 or in illegal format
            user_input = new Scanner( System.in );
            do {
                System.out.println( "Enter the desired functionality (integer number) ..." );

                while ( !user_input.hasNextInt() ) {
                    System.out.println( "Input should be an integer!" );
                    user_input.next();
                }

                choose = user_input.nextInt();
            } while ( ( choose < 1 ) || ( choose > 2 ) );
        } catch ( Exception e ) {
            e.printStackTrace();
        } finally {
            user_input.nextLine();
        }

        String fileLocations[] = new String[ 1 ];
        boolean insertRequiredFiles = false;

        if ( choose == 2 ) {
            insertRequiredFiles = true;
        }

        if ( insertRequiredFiles ) {
            fileLocations = TEN_REQUIRED_INPUTS;
        } else {
            try {
                user_input = new Scanner( System.in );

                System.out.print( "Input file path (full path / relative to Eclipse src folder): " );
                fileLocations[ 0 ] = user_input.nextLine();
            } catch ( Exception e ) {
                e.printStackTrace();
            }
        }

        System.out.println( "\nInserting new record..." );

        for ( String fileLocation : fileLocations ) {
            // Create SQL query
            Path fileLocationPath = Paths.get( fileLocation ).toAbsolutePath();
            StringBuilder sqlQuery = new StringBuilder( "INSERT INTO employees VALUES" );

            try ( BufferedReader br = Files.newBufferedReader( fileLocationPath ) ) {
                br.readLine(); // Skip the header
                String line = "";

                while ( ( line = br.readLine() ) != null ) {
                    if ( line.length() > 0 ) {
                        String[] lineDivided = line.trim().split( "," );

                        // Extend the sqlQuery
                        sqlQuery.append( "(NULL,\""
                                + lineDivided[ 0 ]
                                + "\",\""
                                + lineDivided[ 1 ]
                                + "\",\""
                                + lineDivided[ 2 ]
                                + "\",\""
                                + lineDivided[ 3 ]
                                + "\","
                                + lineDivided[ 4 ]
                                + ")," );
                    }
                }

                sqlQuery.deleteCharAt( sqlQuery.length() - 1 );
                sqlQuery.append( ";" );

            } catch ( IOException e ) {
                e.printStackTrace();
            }

            // Run executeUpdate to communicate with database
            try ( Statement stmt = conn.createStatement() ) {
                stmt.executeUpdate( sqlQuery.toString() );
            } catch ( SQLException ex ) {
                ex.printStackTrace();
            }
        }

        System.out.println( "Record inserted..." );
        // A pause system so user can see the result
        try {
            user_input = new Scanner( System.in );
            System.out.println( "\nGo to Main Menu?(Press Enter): " );

            while ( !user_input.hasNextLine() ) {
                System.out.println( "Input something ..." );
                user_input.next();
            }

        } catch ( Exception e ) {
            e.printStackTrace();
        } finally {
            user_input.nextLine();
        }
    }


    static public void deleteAnEmployee( Connection conn )
    {
        System.out.println( "\n\n--------------------------------------------------------------" );
        System.out.println( "\n                     Delete an Employee                       " );
        System.out.println( "\n--------------------------------------------------------------" );

        Scanner user_input = null;
        int id = 0;

        // User input value
        try {
            do {
                user_input = new Scanner( System.in );

                // Insert employee's ID
                System.out.print( "Input Employee's ID you want to delete: " );
                while ( !user_input.hasNextInt() ) {
                    System.out.println( "Input should be an integer!" );
                    user_input.next();
                }

                id = user_input.nextInt();
            } while ( id <= 0 );
        } catch ( Exception e ) {
            e.printStackTrace();
        }

        String query = "DELETE FROM employees " + "WHERE id = " + id;

        // Run executeUpdate to communicate with database
        try ( Statement stmt = conn.createStatement() ) {
            stmt.executeUpdate( query );
        } catch ( SQLException ex ) {
            ex.printStackTrace();
        }

        System.out.println( "\nRecord deleted..." );
        // A pause system so user can see the result
        try {
            user_input = new Scanner( System.in );
            System.out.println( "Go to Main Menu?(Press Enter): " );

            while ( !user_input.hasNextLine() ) {
                System.out.println( "Input something ..." );
                user_input.next();
            }

        } catch ( Exception e ) {
            e.printStackTrace();
        } finally {
            user_input.nextLine();
        }
    }


    static public void updateAnEmployee( Connection conn )
    {
        System.out.println( "\n\n--------------------------------------------------------------" );
        System.out.println( "\n                    Update an Employee                        " );
        System.out.println( "\n--------------------------------------------------------------" );

        Scanner user_input = null;
        int id = 0;

        // User input value
        try {
            do {
                user_input = new Scanner( System.in );

                // Insert employee's ID
                System.out.print( "Input ID: " );
                while ( !user_input.hasNextInt() ) {
                    System.out.println( "Input should be an integer!" );
                    user_input.next();
                }

                id = user_input.nextInt();
                user_input.nextLine();
            } while ( id <= 0 );
        } catch ( Exception e ) {
            e.printStackTrace();
        }

        System.out.println( "Data found ..." );
        System.out.println( "Insert the new data ...." );

        String lastName = "";
        String firstName = "";
        String email = "";
        String department = "";
        double salary = 0.0;

        // User input values
        try {

            user_input = new Scanner( System.in );

            // Insert last name
            System.out.print( "\nInput Last Name: " );
            while ( !user_input.hasNextLine() ) {
                System.out.println( "Input should be a string!" );
                user_input.next();
            }
            lastName = user_input.nextLine();

            // Insert first name
            System.out.print( "Input First Name: " );
            while ( !user_input.hasNextLine() ) {
                System.out.println( "Input should be a string!" );
                user_input.next();
            }
            firstName = user_input.nextLine();

            // Insert email
            System.out.print( "Input Email: " );
            while ( !user_input.hasNextLine() ) {
                System.out.println( "Input should be a string!" );
                user_input.next();
            }
            email = user_input.nextLine();

            // Insert employee's department
            System.out.print( "Input Department: " );
            while ( !user_input.hasNextLine() ) {
                System.out.println( "Input should be a string!" );
                user_input.next();
            }
            department = user_input.nextLine();

            // Insert salary
            System.out.print( "Input Salary: " );
            while ( !user_input.hasNextDouble() ) {
                System.out.println( "Input should be in double type!" );
                user_input.next();
            }
            salary = user_input.nextDouble();
        } catch ( Exception e ) {
            e.printStackTrace();
        } finally {
            user_input.nextLine();
        }

        String query = "UPDATE employees "
                + "SET last_name = "
                + "\""
                + lastName
                + "\""
                + ", first_name = "
                + "\""
                + firstName
                + "\""
                + ", email = "
                + "\""
                + email
                + "\""
                + ", department = "
                + "\""
                + department
                + "\""
                + ", salary = "
                + "\""
                + salary
                + "\""
                + " WHERE id = "
                + id;

        // Run executeUpdate to communicate with database
        try ( Statement stmt = conn.createStatement() ) {
            stmt.executeUpdate( query );
        } catch ( SQLException ex ) {
            ex.printStackTrace();
        }

        System.out.println( "\nRecord updated..." );
        // A pause system so user can see the result
        try {
            user_input = new Scanner( System.in );
            System.out.println( "Go to Main Menu?(Press Enter): " );

            while ( !user_input.hasNextLine() ) {
                System.out.println( "Input something ..." );
                user_input.next();
            }

        } catch ( Exception e ) {
            e.printStackTrace();
        } finally {
            user_input.nextLine();
        }
    }


    static public void searchEmployee( Connection conn )
    {
        System.out.println( "\n\n--------------------------------------------------------------" );
        System.out.println( "\n                     Search Employee(s)                       " );
        System.out.println( "\n--------------------------------------------------------------" );

        Scanner user_input = null;
        int choose = 0;
        boolean done = false;
        boolean first = true;
        String query = "";

        int id = -1;
        String lastName = "";
        String firstName = "";
        String email = "";
        String department = "";
        double salary = 0.0;

        boolean salaryBiggerThan = true;

        while ( !done ) {
            // A menu to user to choose which condition they want to insert
            System.out.println( "\nWhich condition you want to have?" );
            if ( !first ) {
                System.out.println( "0.   Done" );
            }
            System.out.println( "1.   ID\n"
                    + "2.   Last name\n"
                    + "3.   First name\n"
                    + "4.   Email\n"
                    + "5.   Department\n"
                    + "6.   Salary" );

            // A loop to check if the input not in 1 to 6 or in illegal format
            if ( !first ) {
                try {
                    user_input = new Scanner( System.in );
                    do {
                        System.out.println( "Enter the number ..." );

                        while ( !user_input.hasNextInt() ) {
                            System.out.println( "Input should be an integer!" );
                            user_input.next();
                        }

                        choose = user_input.nextInt();
                    } while ( ( choose < 0 ) || ( choose > 6 ) );
                } catch ( Exception e ) {
                    e.printStackTrace();
                } finally {
                    user_input.nextLine();
                }

            } else {
                try {
                    // A loop to check if the input not in illegal format
                    user_input = new Scanner( System.in );
                    do {
                        System.out.println( "Enter the number ..." );

                        while ( !user_input.hasNextInt() ) {
                            System.out.println( "Input should be an integer!" );
                            user_input.next();
                        }

                        choose = user_input.nextInt();
                    } while ( ( choose < 1 ) || ( choose > 6 ) );
                } catch ( Exception e ) {
                    e.printStackTrace();
                } finally {
                    user_input.nextLine();
                }
            }

            switch ( choose ) {
                case 1:
                    try {
                        // Insert employee's ID
                        System.out.print( "WHERE ID = " );
                        while ( !user_input.hasNextInt() ) {
                            System.out.println( "Input should be an integer!" );
                            user_input.next();
                        }
                        id = user_input.nextInt();
                    } catch ( Exception e ) {
                        e.printStackTrace();
                    } finally {
                        user_input.nextLine();
                    }
                    break;

                case 2:
                    try {
                        // Insert last name
                        System.out.print( "(Case sensitive) WHERE last_name = " );
                        while ( !user_input.hasNextLine() ) {
                            System.out.println( "Input should be a string!" );
                            user_input.next();
                        }
                        lastName = user_input.nextLine();
                    } catch ( Exception e ) {
                        e.printStackTrace();
                    }
                    break;

                case 3:
                    try {
                        // Insert first name
                        System.out.print( "(Case sensitive) WHERE first_name = " );
                        while ( !user_input.hasNextLine() ) {
                            System.out.println( "Input should be a string!" );
                            user_input.next();
                        }
                        firstName = user_input.nextLine();
                    } catch ( Exception e ) {
                        e.printStackTrace();
                    }
                    break;

                case 4:
                    try {

                        // Insert email
                        System.out.print( "(Case sensitive) WHERE email = " );
                        while ( !user_input.hasNextLine() ) {
                            System.out.println( "Input should be a string!" );
                            user_input.next();
                        }
                        email = user_input.nextLine();
                    } catch ( Exception e ) {
                        e.printStackTrace();
                    }
                    break;

                case 5:
                    try {
                        // Insert employee's department
                        System.out.print( "(Case sensitive) WHERE department = " );
                        while ( !user_input.hasNextLine() ) {
                            System.out.println( "Input should be a string!" );
                            user_input.next();
                        }
                        department = user_input.nextLine();
                    } catch ( Exception e ) {
                        e.printStackTrace();
                    }
                    break;

                case 6:
                    System.out.println( "1.   Salary bigger than (number)" + "\n2.   Salary smaller than (number)" );
                    try {
                        user_input = new Scanner( System.in );
                        do {
                            System.out.println( "Enter the number ..." );

                            while ( !user_input.hasNextInt() ) {
                                System.out.println( "Input should be an integer!" );
                                user_input.next();
                            }

                            choose = user_input.nextInt();
                        } while ( ( choose != 1 ) && ( choose != 2 ) );
                    } catch ( Exception e ) {
                        e.printStackTrace();
                    } finally {
                        user_input.nextLine();
                    }

                    switch ( choose ) {
                        case 1:
                            try {
                                // Insert salary
                                System.out.print( "WHERE Salary > " );
                                while ( !user_input.hasNextDouble() ) {
                                    System.out.println( "Input should be in double type!" );
                                    user_input.next();
                                }
                                salary = user_input.nextDouble();
                            } catch ( Exception e ) {
                                e.printStackTrace();
                            } finally {
                                user_input.nextLine();
                            }
                            break;

                        case 2:
                            salaryBiggerThan = false;
                            try {
                                // Insert salary
                                System.out.print( "WHERE Salary < " );
                                while ( !user_input.hasNextDouble() ) {
                                    System.out.println( "Input should be in double type!" );
                                    user_input.next();
                                }
                                salary = user_input.nextDouble();
                            } catch ( Exception e ) {
                                e.printStackTrace();
                            } finally {
                                user_input.nextLine();
                            }
                            break;
                    }
                    break;

                default:
                    done = true;
                    break;
            }

            if ( !done ) {
                char next = '\u0000';
                do {
                    try {
                        System.out.print( "Do you have another condition (Y/N): " );
                        while ( !user_input.hasNextLine() ) {
                            System.out.println( "Input should be Y or N!" );
                            user_input.next();
                        }
                        next = Character.toUpperCase( user_input.nextLine().charAt( 0 ) );
                    } catch ( Exception e ) {
                        e.printStackTrace();
                    }
                } while ( next != 'Y' && next != 'N' );

                if ( next == 'N' ) {
                    done = true;
                }
            }

            if ( done ) {
                query = "SELECT * FROM employees WHERE";
                if ( id != -1 ) {
                    query = query + " id = " + id + " and";
                }

                if ( !lastName.isEmpty() ) {
                    query = query + " last_name = \"" + lastName + "\" and";
                }

                if ( !firstName.isEmpty() ) {
                    query = query + " first_name = \"" + firstName + "\" and";
                }

                if ( !email.isEmpty() ) {
                    query = query + " email = \"" + email + "\" and";
                }

                if ( !department.isEmpty() ) {
                    query = query + " department = \"" + department + "\" and";
                }

                if ( salary > 0.0 ) {
                    if ( salaryBiggerThan ) {
                        query = query + " salary > " + salary + " and";
                    } else {
                        query = query + " salary < " + salary + " and";
                    }
                }

                // Delete the last 'and' in String query
                query = query.substring( 0, query.length() - 4 );
            }

            first = false;
        }

        try ( Statement stmt = conn.createStatement() ) {

            int totalEmployees = 0;

            ResultSet rs = stmt.executeQuery( query );

            System.out.println( "\n--------------------------------------------------------------" );
            System.out.println( "\n                        Search Result                         " );
            System.out.println( "\n--------------------------------------------------------------" );

            while ( rs.next() ) {
                id = rs.getInt( "id" );
                lastName = rs.getString( "last_name" );
                firstName = rs.getString( "first_name" );
                email = rs.getString( "email" );
                department = rs.getString( "department" );
                salary = rs.getDouble( "salary" );

                System.out.println( "ID: "
                        + id
                        + "\nName: "
                        + lastName
                        + ", "
                        + firstName
                        + "\nEmail: "
                        + email
                        + "\nDepartment: "
                        + department
                        + "\nSalary: "
                        + salary );
                System.out.println( "---------------------" );

                totalEmployees++;

            }
            System.out.println( "TOTAL: " + totalEmployees + " employees" );

        } catch ( SQLException se ) {
            se.printStackTrace();
        } catch ( Exception e ) {
            e.printStackTrace();
        }

        try {
            user_input = new Scanner( System.in );
            System.out.println( "\nGo to Main Menu?(Press Enter): " );

            while ( !user_input.hasNextLine() ) {
                System.out.println( "Input something ..." );
                user_input.next();
            }

        } catch ( Exception e ) {
            e.printStackTrace();
        } finally {
            user_input.nextLine();
        }
    }


    static public void setupInitialTable()
    {
        System.out.println( "\nResetting to initial table." );

        Path sqlSchemaPath = Paths.get( INITIAL_DATABASE_SETUP );

        String sqlSchemaAbsoluteString = sqlSchemaPath.toAbsolutePath().toString();
        String importSchemaCommand = "mysql -u"
                + DATABASE_USER
                + " -p"
                + DATABASE_PASSWORD
                + " < "
                + sqlSchemaAbsoluteString;

        try {
            ShellCommand.execute( importSchemaCommand );
        } catch ( ExecutionFailedException | InterruptedException | IOException e ) {
            e.printStackTrace();
        }

        System.out.println( "Succesfully reset to initial table." );

        Scanner user_input = null;
        try {
            user_input = new Scanner( System.in );
            System.out.println( "\nGo to Main Menu?(Press Enter): " );

            while ( !user_input.hasNextLine() ) {
                System.out.println( "Input something ..." );
                user_input.next();
            }

        } catch ( Exception e ) {
            e.printStackTrace();
        } finally {
            user_input.nextLine();
        }
    }
}
